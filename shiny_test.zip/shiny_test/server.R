library(shiny)
library(ggplot2)
library(maps)
library(dplyr)

shinyServer(function(input, output) {
  
  
  data = read.csv("data/owid-covid-data.csv")
  bar = data[,c(3,4,6)]
  bar$date <- as.Date(bar$date)
  world_map = map_data("world2")
  world_map = world_map %>%
    mutate(region = replace(region, region == "UK", "United Kingdom")) %>%
    mutate(region = replace(region, region == "USA", "United States"))
  
  output$distPlot <- renderPlot({
    time <- input$Date
    sub <- subset(bar,date == time)
    #sub <- sub[order(-sub$new_cases),]
    #sub <- head(sub,10)
    
    d = left_join(world_map,sub,by = c("region" = "location"))

    ggplot(data = d, aes(x = long, y = lat, group = group,fill = new_cases)) +
      geom_polygon(colour = "gray") + 
      theme(legend.position = "right", aspect.ratio = 0.6) +
      scale_fill_continuous(low = "cyan",high = "blue",na.value="white")+ 
      ggtitle("Map of World")
  })
})

