library(shiny)
library(shinythemes)

data = read.csv("data/owid-covid-data.csv")
time = data[,4]
time <- as.Date(time)


# Define UI for application that draws a histogram
shinyUI(fluidPage(#theme = "bootstrap.css",
  
  # Application title
  titlePanel("COVID"),
  
  # Sidebar with a slider input for the number of bins
  navbarPage("New case", id="main",
             tabPanel("new case",
                      sidebarLayout(
                        sidebarPanel(
                          sliderInput("Date",
                                      "Date:",
                                      min = min(time),
                                      max = max(time),
                                      value = min(time))
                          ),
                        mainPanel(plotOutput("distPlot"))
                        )
                      )
             )
))